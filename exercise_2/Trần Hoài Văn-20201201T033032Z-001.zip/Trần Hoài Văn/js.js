$(document).ready(function () {
    $('.nav1').click(function () {
        $('.test').addClass('unblock');
        $('.headerUl li').removeClass('activeList');
        $('.nav1').addClass('activeList');
        $('.test1').removeClass('unblock');
    })
    $('.nav2').click(function () {
        $('.test').addClass('unblock');
        $('.headerUl li').removeClass('activeList');
        $(this).addClass('activeList');
        $('.test2').removeClass('unblock');
    })
    $('.nav3').click(function () {
        $('.test').addClass('unblock');
        $('.headerUl li').removeClass('activeList');
        $(this).addClass('activeList');
        $('.test3').removeClass('unblock');
    })


    let Arr = [];
    let array = [];
    let Arr2 = [array];
    let index = 0;
    let data = $('.1main');
    for (let i = 0; i < data.length; i++) {
        data[i].onclick = function () {
            $('.1main').removeClass('active');
            $(this).toggleClass('active');
        }
    }
    // TEST 1
    $('.Test1_1').click(function () {
        Arr = [];
        $('.test1main').addClass('unblock');
        $('.1_1').removeClass('unblock');
        $('.1_1Form').removeClass('unblock');
        $('.data1_1').html('');
        $('.data1_11').html('');
        index = 0;
    })
            $('.addArr').click(function () {
                let val = parseInt($('.test1_input').val());
                if (isNaN(val)) { $('.data1_11').html('<h3 style="color:red">MUST BE A NUMBER'); return false;} else $('.data1_11').html('');
                Arr.push(val);
                console.log(Arr);
                $('.data1_1').append(`<p>Arr[${index++}]=${val}</p>`);
                $('.test1_input').val('');
                $('.test1_input').focus();
            })
            $('.btnfinish').click(function () {
                $('.data1_1').html('<h3>Your new Arr</h3>');
                    $('.data1_1').append(`<p>Arr = ${Arr}</p>`);
                    $('.1_1Form').addClass('unblock');
            })
    // Test 2
    $('.Test1_2').click(function () {
        $('.test1main').addClass('unblock');
        $('.1_2').removeClass('unblock');
        $('.data1_2').html('')
        $('.data1_2').append(`<p>Arr = ${Arr}</p>`);
    })
    // Test 3
    $('.Test1_3').click(function () { 
        $('.test1main').addClass('unblock');
        $('.1_3').removeClass('unblock');
        $('.FindArr').removeClass('unblock');
    })
    $('.FindArr').click(function () {
        let val = parseInt($('.test12_input').val());
        if (Arr.indexOf(val) != -1) {
            $('.data1_3').html(`<h3>FOUND <strong>"${val}"</strong> AT <strong>Arr[${Arr.indexOf(val)}]</strong></h3>`);
        } else  $('.data1_3').html(`<h3>NOT FOUND</h3>`);
    })
    // Test 4
    $('.Test1_4').click(function () {
        $('.test1main').addClass('unblock');
        $('.1_4').removeClass('unblock');
        let arr1 = Arr.sort(function (a, b) {
            return a - b;
        })
        $('.data1_4').html(`<h3>MAXIMUM VAL IS: ${arr1[arr1.length-1]}</h3>`);
    })
    // Test 5
    $('.Test1_5').click(function () {
        $('.test1main').addClass('unblock');
        $('.1_5').removeClass('unblock');
        let sum = 0;
        Arr.forEach(function (item) {
            sum += item;
        })
        $('.data1_5').html(`<h3>SUM IS: ${sum}</h3>`);
    })
    // Test 6
    $('.Test1_6').click(function () {
        $('.test1main').addClass('unblock');
        $('.1_6').removeClass('unblock');
         let arr1 = Arr.sort(function (a, b) {
            return a - b;
         })
         $('.data1_6').html(`<h3>ARRAY AFTER SORT ASCENDING: ${Arr}</h3>`);
    })
    // Test 7
    $('.Test1_7').click(function () {
        $('.test1main').addClass('unblock');
        $('.1_7').removeClass('unblock');
        let arr1 = Arr.sort(function (a, b) {
           return b-a;
        })
        $('.data1_7').html(`<h3>ARRAY AFTER SORT DESCENDING: ${Arr}</h3>`);
    })
    
    // ----------------------------2------------------------------------------------
    let data2 = $('.2main');
    for (let i = 0; i < data2.length; i++){
        $('.test2main').addClass('unblock');
        data2[i].onclick = function () {
            $('.test2main').addClass('unblock');
            $('.2main').removeClass('active');
            $(this).toggleClass('active');
        }
    }
    // Test 2_1
    $('.Test2_1').click(function () {
        $('.2_1').removeClass('unblock');
        $('.2_1Form').removeClass('unblock');
        $('.test23_input').addClass('unblock');
        $('.add3').addClass('unblock');
        Arr2 = [];
    })
    $('.add2').click(function () {
        let sum = 0;
        let n = parseInt($('.test21_input').val());
        let m = parseInt($('.test22_input').val());
        $('.2_1Form').addClass('unblock');
        for (let i = 0; i < m; i++){
            Arr2[i] = [];
            for (let j = 0; j < n; j++){
                Arr2[i][j] = parseInt(prompt('Enter the value of Arr[' + i + ',' + j + ']'));
                sum += Arr2[i][j];
            }
        }
        $('.data2_11').html('<h3>Add new Arr successfully</h3>')
        //  Test 2_2
        $('.Test2_2').click(function () {
            $('.2_2').removeClass('unblock');
            $('.data2_2').html('');
            for (let i = 0; i < m; i++){
                for (let j = 0; j < n; j++){
                    $('.data2_2').append(`<span>${Arr2[i][j]}&nbsp</span>`);
                }
                $('.data2_2').append('<br>')
            }
        })
        // Test 2_3
        $('.Test2_3').click(function () {
            $('.2_3').removeClass('unblock');
            $('.data2_3').html(`<h3>SUM OF ALL ELEMENTS OF ARRAY: ${sum}`);
        })
        // Test 2_4
        $('.Test2_4').click(function () {
            $('.2_4').removeClass('unblock');
            $('.FindArr2').click(function () {
                let key = { x: -1, y:-1}
                let val4 = parseInt($('.test24_input').val());
                for (let i = 0; i < m; i++){
                    for (let j = 0; j < n; j++){
                        if (Arr2[i][j] == val4) {
                            key.x = i;
                            key.y = j;
                        }
                    }
                }
                if (key.x != -1) {
                    $('.data2_4').html(`<h3>FOUND ${val4} AT ARR2[${key.x},${key.y}]</h3>`);
                } else { $('.data2_4').html(`<h3>NOT FOUND</h3>`);}
            })
            
        })
        // Test 2_5
        $('.Test2_5').click(function () {
            $('.2_5').removeClass('unblock');
            let newarray = [];
            for (let i = 0; i < m; i++){
                for (let j = 0; j < n; j++){
                    newarray.push(Arr2[i][j]);
                }
            }
            newarray.sort(function (a, b) { return a - b });
            let index = 0;
            for (let i = 0; i < m; i++){
                for (let j = 0; j < n; j++){
                    Arr2[i][j] = newarray[index];
                    index++;
                }
            }
            $('.data2_5').html('');
            for (let i = 0; i < m; i++){
                for (let j = 0; j < n; j++){
                    $('.data2_5').append(`<span>${Arr2[i][j]}&nbsp</span>`);
                }
                $('.data2_5').append('<br>')
            }

        })
    })
// ------------------------------3----------------------------------
let Arr3 = [];
let data3 = $('.3main');
for (let i = 0; i < data3.length; i++){
    $('.test3main').addClass('unblock');
    data3[i].onclick = function () {
        $('.test3main').addClass('unblock');
        $('.3main').removeClass('active');
        $(this).toggleClass('active');
    }
}
    $('.Test3_1').click(function () {
        Arr3 = [];
        $('.3_1').removeClass('unblock');
        $('.test3form').addClass('unblock');
        $('.add3').removeClass('unblock');
        $('.add31').addClass('unblock');
        $('.test3formLength').removeClass('unblock');
    })

    $('.add3').click(function () {
        $('.test3form').removeClass('unblock');
        $('.test3formLength').addClass('unblock');
        $('.add3').addClass('unblock');
        $('.add31').removeClass('unblock');
        let val = parseInt($('.test31_input').val());
        let i = 0;
        $('.add31').click(function () {
            if (i < val) {
                let val3 = $('.test32_input').val();
                Arr3.push(val3);
                i++;
                $('.test32_input').val('');
                $('.test32_input').focus();
            }
            if (i==val)
                {$('.data3_1').html('<h3>CREATE NEW ARRAY SUCCESSFULLY</h3>');
                    $('.test3form').addClass('unblock');
                    $('.add31').addClass('unblock');
                }
        })
    })

    // Test 3_2
    $('.Test3_2').click(function () {
        $('.3_2').removeClass('unblock');
        $('.data3_2').html('')
        Arr3.forEach(function (item,index) {
            $('.data3_2').append(`<p>Array[${index}] = ${item}</p>`)
        })
    })

     // Test 3_5
    $('.Test3_5').click(function () {
        $('.3_5').removeClass('unblock');
        $('.data3_5').html('');
        let arr3sort = Arr3.sort();
        arr3sort.forEach(function (item, index) {
            $('.data3_5').append(`<p>Array[${index}] = ${item}</p>`)
        })
    })

})